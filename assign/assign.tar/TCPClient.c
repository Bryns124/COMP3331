// NOTE: Used mostly sample network sockets code.

#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <stdbool.h>

// Server host and port number are defined here for simple usage, but for some
// lab/assignment requires, they may need to be passed from command line parameter
// which should be obtained from the second parameter *argv[] of the main() function
#define SERVER_IP "127.0.0.1"
#define BUFFER_LEN 1024

// Get the "name" (IP address) of who we're communicating with.
char *get_name(struct sockaddr_in *sa, char *name);

// Populate a sockaddr_in struct with the specified IP / port to connect to.
void fill_sockaddr(struct sockaddr_in *sa, char *ip, int port);

// A wrapper function for fgets, similar to Python's built-in 'input' function.
void get_input(char *buffer, char *msg);

// Displays the commands after the user is logged in.
void show_commands(int client_socket);

// Logs the user in and sends information to server.
void login_user(int udp_port, int client_socket);

int main(int argc, char *argv[]) {

    if (argc != 4) {
        printf("===== Requires server address, server port and udp port =====\n");
        return -1;
    }
    char server_address[16] = SERVER_IP;
    strcpy(server_address, argv[1]);
    int server_port = atoi(argv[2]);
    int udp_port = atoi(argv[3]);
    char user[BUFFER_LEN];

    // Create the client's socket.
    //
    // The first parameter indicates #the address family; in particular,
    // `AF_INET` indicates that the underlying network is using IPv4.
    //
    // The second parameter indicates that the socket is of type
    // SOCK_DGRAM, which means it is a UDP socket (rather than a TCP
    // socket, where we use SOCK_STREAM).
    //
    // This returns a file descriptor, which we'll use with our send /
    // recv functions later.
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);

    get_input(user, "Username: ");
    while (1) {
        char pass[BUFFER_LEN], login[128], buffer[BUFFER_LEN];
        // Create the sockaddr that the client will use to send data to the
        // server.
        struct sockaddr_in sockaddr_to;
        fill_sockaddr(&sockaddr_to, SERVER_IP, server_port);
        connect(client_socket, (struct sockaddr*)&sockaddr_to, sizeof(sockaddr_to));

        // Combine user and pass to make login to check if login exists.
        get_input(pass, "Password: ");
        sprintf(login, "%s %s", user, pass);

        // Now that we have a socket and a message, we send the message
        // through the socket to the server and wait for the reply.
        int numbytes_login = send(client_socket, login, strlen(login), 0);
        numbytes_login = recv(client_socket, buffer, BUFFER_LEN, 0);

        // Null terminate and remove the newline in the buffer.
        buffer[numbytes_login] = '\0';
        buffer[strcspn(buffer, "\n")] = '\0';

        // Create the sockaddr that the client will use to receive data from
        // the server.
        // We need to create a variable to store the length of the sockaddr
        // we're using here, which the recvfrom function can update if it
        // stores a different amount of information in the sockaddr.
        struct sockaddr_in sockaddr_from;
        socklen_t sockaddr_from_len = sizeof(sockaddr_from);

        // If the login exists, the user is logged in and can use the commands.
        // Otherwise, the user is asked to reenter the pass for the same
        // user until correct or max attemots is reached.
        int login_fail = strcmp(buffer, "Can login");
        if (!login_fail) {
            login_user(udp_port, client_socket);
            show_commands(client_socket);
        }
        else {
            printf("Invalid password. Please try again\n");
        }
    }
    return 0;
}

// Displays the commands after the user is logged in.
void login_user(int udp_port, int client_socket) {
    int udp_port_net = htonl(udp_port);
    send(client_socket, &udp_port_net, sizeof(int), 0);
    printf("Welcome to TOOM!\n");
}

// Logs the user in and sends information to server.
void show_commands(int client_socket) {
    while (1) {
        char command[BUFFER_LEN], response[BUFFER_LEN];
        get_input(command, "Enter one of the following commands: (BCM, ATU, SRB, SRM, RDM, OUT, UPD\n");
        send(client_socket, command, strlen(command), 0);
        recv(client_socket, response, BUFFER_LEN, 0);
        printf("%s", response);
    }
}

// Wrapper function for fgets, similar to Python's built-in 'input'
// function.
void get_input(char *buffer, char *msg) {
    printf("%s", msg);
    fgets(buffer, BUFFER_LEN, stdin);
    buffer[strcspn(buffer, "\n")] = '\0'; // Remove the newline
}

// Populate a `sockaddr_in` struct with the IP / port to connect to.
void fill_sockaddr(struct sockaddr_in *sa, char *ip, int port) {

    // Set all of the memory in the sockaddr to 0.
    memset(sa, 0, sizeof(struct sockaddr_in));

    // IPv4.
    sa->sin_family = AF_INET;

    // We need to call `htons` (host to network short) to convert the
    // number from the "host" endianness (most likely little endian) to
    // big endian, also known as "network byte order".
    sa->sin_port = htons(port);
    sa->sin_addr.s_addr = inet_addr(SERVER_IP);
}

// Get the "name" (IP address) of who we're communicating with.
char *get_name(struct sockaddr_in *sa, char *name) {
    inet_ntop(sa->sin_family, &(sa->sin_addr), name, BUFFER_LEN);
    return name;
}